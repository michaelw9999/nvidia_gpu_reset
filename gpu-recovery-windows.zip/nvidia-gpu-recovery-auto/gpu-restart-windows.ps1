#requires -Version 5.1
#requires -RunAsAdministrator
# UNTESTED. Windows device restart only, not an ACPI slot power-cycle.
# Save your work first. The screen may go blank and applications may close.

$GpuInstanceId = ''  # Copy the complete InstanceId shown by Get-PnpDevice.
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($GpuInstanceId)) {
    throw 'Set GpuInstanceId first. See README.md.'
}

$devices = @(Get-PnpDevice -Class Display -InstanceId $GpuInstanceId -PresentOnly)
if ($devices.Count -ne 1 -or $devices[0].InstanceId -notlike 'PCI\VEN_10DE&*') {
    throw 'The selected device is not a present NVIDIA display adapter.'
}

Write-Host "Restarting $($devices[0].FriendlyName). The screen may go blank."
& "$env:SystemRoot\System32\pnputil.exe" /restart-device $GpuInstanceId
$result = $LASTEXITCODE
if ($result -eq 3010) {
    Write-Warning 'Windows requires a reboot to complete the restart. No reboot was initiated.'
    exit 3010
}
if ($result -ne 0) {
    throw "Windows could not restart the device (exit $result). A reboot may be needed."
}

Start-Sleep -Seconds 5
$device = Get-PnpDevice -InstanceId $GpuInstanceId -PresentOnly
if ($device.Status -ne 'OK') {
    throw "Device status is $($device.Status). Recovery is not confirmed."
}
Write-Host 'Windows reports the device as OK. Test your application before resuming normal use.'
