# NVIDIA GPU recovery

Attempt to recover a hung NVIDIA GPU without rebooting the computer. This is a recovery workaround, not a fix for the crash. Related: [NVIDIA issue #1151](https://github.com/NVIDIA/open-gpu-kernel-modules/issues/1151).

## Linux

**Save your work and close GPU applications. Run from SSH or a text console, not a desktop terminal. The desktop will stop.**

```bash
sudo bash gpu-recover.sh
```

No configuration is needed when one NVIDIA GPU and one suitable ACPI power resource can be identified. The script automatically finds `GPU`, `BRIDGE`, and `ACPI_POWER` using Linux's device tree and firmware power-resource links.

It saves logs, unloads NVIDIA drivers, requests a slot power-cycle, waits for a stable connection, restores the previous BAR1 size when available, and reloads drivers and stopped services.

**Requirements:** Bash 4.4+, systemd/udev, NVIDIA's driver and `nvidia-smi`, `acpi_call` for the running kernel, `pciutils`, `psmisc`, and standard Linux utilities. Missing dependencies are reported; the script does not install them.

### When detection cannot choose

It stops before shutting down the desktop if there are multiple possible GPUs, unrelated devices behind the bridge, or missing, ambiguous, or known-shared ACPI power resources.

Three commented examples at the top allow manual overrides. Use only addresses and a power resource verified for that machine. The example ACPI path is **not** a universal default. A GPU already removed from Linux's device tree cannot be automatically identified.

Firmware mappings do not guarantee a successful physical power-cycle. A reboot or full shutdown may still be needed. Drivers for **all NVIDIA GPUs** are unloaded, and udev event processing is temporarily paused. Failed recovery may leave services stopped; the script lists them.

Logs: `/var/log/gpu-recovery/`. A successful `nvidia-smi` check is not an application test; check your application afterward.

## Windows helper (unchanged, untested)

`gpu-restart-windows.ps1` requests a Windows device restart, **not** the Linux ACPI power-cycle.

In Administrator PowerShell, find the adapter:

```powershell
Get-PnpDevice -Class Display | Format-List FriendlyName, InstanceId, Status
```

Copy its full `InstanceId` into that helper, save your work, and run:

```powershell
.\gpu-restart-windows.ps1
```

Requires Windows 10 version 2004 or newer. It does not request an automatic reboot and has not been executed here.

## Checks

Linux: Bash syntax check and 30 mocked detection/recovery/failure scenarios passed. These tests used fake device files and commands, not real hardware. They do not establish motherboard compatibility.

## References

[Linux ACPI resource links](https://github.com/torvalds/linux/blob/master/drivers/acpi/power.c) · [ACPI power resources](https://uefi.org/specs/ACPI/6.5/07_Power_and_Performance_Mgmt.html) · [acpi_call](https://github.com/nix-community/acpi_call) · [Windows PnPUtil](https://learn.microsoft.com/en-us/windows-hardware/drivers/devtest/pnputil-command-syntax)
